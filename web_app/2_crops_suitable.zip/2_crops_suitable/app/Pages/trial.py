# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 16:04:16 2024

@author: rampr
"""

import streamlit as st
import pandas as pd
import pickle

# Layout columns
col1, col2 = st.columns(2)

# Input fields in the first column
with col1:
    Fertility = st.selectbox("Fertility", ["High", "Moderate"])
    Photoperiod = st.selectbox("Photoperiod", ["Day Neutral", "Long Day Period", "Short Day Period"])
    NPKRatio = st.selectbox("N-P-K Ratio", ["5:10:05", "5:10:10", "6:06:06", "8:15:36", "10:10:05", "10:10:10", "13:13:13", "20:10:20", "22:12:13", "75:37.5:37.5"])
    Temperature = st.number_input('Temperature', min_value=0.0, max_value=100.0, value=20.0)
    Rainfall = st.number_input('Rainfall', min_value=0.0, max_value=2000.0, value=1932.0)
    Light_Hours = st.number_input('Light Hours', min_value=0.0, max_value=100.0, value=12.0)
    Light_Intensity = st.number_input('Light Intensity', min_value=0.0, max_value=900.0, value=860.0)

# Input fields in the second column
with col2:
    Rh = st.number_input('Rh', min_value=0.0, max_value=100.0, value=92.0)
    Nitrogen = st.number_input('Nitrogen', min_value=0.0, max_value=100.0, value=89.0)
    Phosphorus = st.number_input('Phosphorus', min_value=0.0, max_value=100.0, value=40.0)
    Potassium = st.number_input('Potassium', min_value=0.0, max_value=200.0, value=180.0)
    Category_pH = st.selectbox("Category_pH", ["acidic", "low_acidic", "low_alkaline", "neutral"])
    Soil_Type = st.selectbox("Soil_type", ["Loam", "Sandy", "Sandy Loam"])
    Season = st.selectbox("Season", ["Fall", "Spring", "Summer", "Winter"])

# Split the N-P-K ratio
ratio = NPKRatio.split(':')
Nitrogen_Ratio = float(ratio[0])
Phosphorus_Ratio = float(ratio[1])
Potassium_Ratio = float(ratio[2])

# Prepare input data
input_data = {
    'Fertility': Fertility,
    'Photoperiod': Photoperiod,
    'Temperature': Temperature,
    'Rainfall': Rainfall,
    'Light_Hours': Light_Hours,
    'Light_Intensity': Light_Intensity,
    'Rh': Rh,
    'Nitrogen': Nitrogen,
    'Phosphorus': Phosphorus,
    'Potassium': Potassium,
    'Category_pH': Category_pH,
    'Soil_Type': Soil_Type,
    'Season': Season,
    'Nitrogen_Ratio': Nitrogen_Ratio,
    'Phosphorus_Ratio': Phosphorus_Ratio,
    'Potassium_Ratio': Potassium_Ratio
}

# Convert input data to DataFrame
input_df = pd.DataFrame([input_data])

# Load the models
try:
    with open('./classifycrop.pkl', 'rb') as file:
        classify_model = pickle.load(file)
    with open('./predictingyield.pkl', 'rb') as file:
        yield_model = pickle.load(file)
    
    # Ensure all expected columns are present
    expected_columns_classify = classify_model.feature_names_in_
    expected_columns_yield = yield_model.feature_names_in_

    # Initialize missing columns with zeros for classification model
    for col in expected_columns_classify:
        if col not in input_df.columns:
            input_df[col] = 0  # or a default value

    # Ensure the column order matches the classification model's expected input
    input_df_classify = input_df[expected_columns_classify]

    # Prediction button
    if st.button("Predict"):
        st.write("**You have submitted the below data.**")
        st.write(input_df_classify)

        # Predict the crop type
        crop_prediction = classify_model.predict(input_df_classify)
        st.success(f"Predicted Crop: {crop_prediction[0]}")

        # Prepare input for yield prediction
        input_df['Predicted_Crop'] = crop_prediction[0]

        # Initialize missing columns with zeros for yield model
        for col in expected_columns_yield:
            if col not in input_df.columns:
                input_df[col] = 0  # or a default value

        # Ensure the column order matches the yield model's expected input
        input_df_yield = input_df[expected_columns_yield]

        # Predict the yield
        yield_prediction = yield_model.predict(input_df_yield)
        st.success(f"Predicted Yield: {yield_prediction[0]} tons per hectare")
except Exception as e:
    st.error(f"An error occurred: {e}")